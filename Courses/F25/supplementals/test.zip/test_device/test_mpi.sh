# !/bin/bash
echo "==================================================="
echo "Testing ***_MPI_*** on ***_$(hostname)_***"
# Move to current folder and create compiled folder
cd "$(dirname "$0")"
mkdir -p compiled


mpicc ./test_case/hello_mpi.c -o ./compiled/hello_mpi

# Check if compilation succeeded
if [ $? -ne 0 ]; then
    echo "❌ Compilation failed!"
    exit 1
fi
echo "✅ Compilation successful!"
echo
cd compiled
mpirun -np 2 hello_mpi  # use 2 processors
# Check if execution succeeded
if [ $? -ne 0 ]; then
    echo "❌ Execution failed!"
    exit 1
fi
echo "✅ passed 2 processes test..."
echo
mpirun -np 8 hello_mpi  # use 8 processors
# Check if execution succeeded
if [ $? -ne 0 ]; then
    echo "❌ Execution failed!"
    exit 1
fi
echo "✅ passed 8 processes test..."
echo
mpirun hello_mpi      # use number of processors equal to total machine procs
# Check if execution succeeded
if [ $? -ne 0 ]; then
    echo "❌ Execution failed!"
    exit 1
fi
echo "✅ passed the test with all available processors"
echo
echo "✅ Program ran successfully!"
echo "==================================================="
