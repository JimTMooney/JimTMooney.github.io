// mpi_hello.c: C Example of hello world with MPI.  Compile and run as


#include <stdio.h>
#include <mpi.h>

int main (int argc, char *argv[]){
  int rank;                     // the id of this processor
  int size;                     // the number of processors being used

  MPI_Init (&argc, &argv);               // starts MPI
  MPI_Comm_rank (MPI_COMM_WORLD, &rank); // get current process id
  MPI_Comm_size (MPI_COMM_WORLD, &size); // get number of processes

  // Say hello from this proc
  printf( "Proc %d of %d says 'Hello world'\n", rank, size );

  MPI_Finalize();
  return 0;
}
