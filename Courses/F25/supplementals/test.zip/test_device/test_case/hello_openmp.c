#include <stdio.h>
#include <omp.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    // Parallel region starts
    int nthreads = 4; // default

    if (argc > 1) {
        nthreads = atoi(argv[1]); // take arg
    }
    omp_set_num_threads(nthreads);

    #pragma omp parallel
    {
        int thread_id = omp_get_thread_num();
        int total_threads = omp_get_num_threads();
        printf("Hello World from thread %d out of %d\n", thread_id, total_threads);
    }
    // Parallel region ends
    return 0;
}
