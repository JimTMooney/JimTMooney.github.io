# !/bin/bash
echo "==================================================="
module load soft/cuda

echo "Testing ***_Cuda_*** on ***_$(hostname)_***"

cd "$(dirname "$0")"
mkdir -p compiled

# Compile hello.cu with nvcc
nvcc ./test_case/hello_cuda.cu -o ./compiled/hello_cuda

# Check if compilation succeeded
if [ $? -ne 0 ]; then
    echo "❌ Compilation failed!"
    exit 1
fi

echo "✅ Compilation successful!"
echo
# Run the program
./compiled/hello_cuda

# Check if execution succeeded
if [ $? -ne 0 ]; then
    echo "❌ Execution failed!"
    exit 1
fi
echo "✅ passed the CUDA test..."
echo
echo "✅ Program ran successfully!"
echo "==================================================="
