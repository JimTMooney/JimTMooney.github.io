# !/bin/bash
echo "==================================================="
echo "Testing ***_OpenMP_*** on ***_$(hostname)_***"
# Move to current folder and create compiled folder
cd "$(dirname "$0")"
mkdir -p compiled


gcc ./test_case/hello_openmp.c -o ./compiled/hello_openmp -fopenmp 


# Check if compilation succeeded
if [ $? -ne 0 ]; then
    echo "❌ Compilation failed!"
    exit 1
fi
echo "✅ Compilation successful!"
echo
cd compiled
./hello_openmp 8
# Check if execution succeeded
if [ $? -ne 0 ]; then
    echo "❌ Execution failed!"
    exit 1
fi
echo "✅ passed 8 threads test..."
echo
echo "✅ Program ran successfully!"
echo "==================================================="