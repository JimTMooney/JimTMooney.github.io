#pragma once

#define MAT_SIZE 16
#define M 4
#define N 4
#define K 4
#define NUM_A 512
#define NUM_B 512

#define HARD_CODED_SPEEDUP 100.0f